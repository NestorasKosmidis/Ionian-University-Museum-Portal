<?php /* Custom Footer */ ?>


<footer class="custom-footer">
    <div class="footer-wrapper dark-bg">
        <div class="footer-wrap">
            <div class="footer-top-wrapper">
                <div class="footer-logo-wrap">
                    <?php if(function_exists( 'the_custom_logo' ) ):?>
                        <?php if ( get_custom_logo() ) : ?>
                            <?php the_custom_logo(); ?>
                        <?php endif; ?>
                    <?php endif;?>   
                </div>
                <div class="footer-menu-wrapper show-on-scroll slide-left">
                    <div class="footer-menus-wrapper-inner">
                        <div class="footer-menu-wrap">
                            <?php wp_nav_menu( array( 'theme_location' => 'footer-menu' ) ); ?>
                        </div>
                        <div class="footer-menu-wrap">
                            <?php wp_nav_menu( array( 'theme_location' => 'footer-menu-right' ) ); ?>
                        </div>
                    </div>
                    <div class="footer-socials-wrap">
                        <div class="footer-socials-wrap-bot">
                            <?php if (get_field('instagram','options')): ?>
                                <a href="<?php the_field('instagram','options') ?>" class="social-btn" target="_blank">
                                    <span class="icon-instagram"></span>
                                </a>
                            <?php endif; ?>

                            <?php if (get_field('facebook','options')): ?>
                                <a href="<?php the_field('facebook','options') ?>" class="social-btn" target="_blank">
                                    <span class="icon-facebook"></span>
                                </a>
                            <?php endif; ?>

                            <?php if (get_field('twitter','options')): ?>
                                <a href="<?php the_field('twitter','options') ?>" class="social-btn" target="_blank">
                                    <span class="icon-x-twitter"></span>
                                </a>
                            <?php endif; ?>
                        </div>
                        <div class="footer-info-wrap">
                            <?php if (get_field('email','options')): ?>
                                <a href="mailto:<?php the_field('email','options') ?>" class="footer-text" target="_blank">
                                    <?php the_field('email','options'); ?>
                                </a>
                            <?php endif; ?>
                            <?php if (get_field('address','options')): ?>
                                <a href="#" class="footer-text">
                                    <?php the_field('address','options'); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <div class="footer-bottom-wrap">
        <span class="footer-copyright"> Copyright <?php echo date("Y");?> &copy; Nestoras | All Rights Reserved</span>
        <span class="footer-signature"><?php _e('Developed by ','text-domain');?> <a href="" rel="noopener noreferrer" target="_blank" title="Nestoras">Nestoras</a></span>
    </div>


</footer>



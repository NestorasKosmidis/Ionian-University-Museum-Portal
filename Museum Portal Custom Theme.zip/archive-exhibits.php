<?php
/**
 * Archive template for Exhibits (CPT: exhibits)
 */
get_header();

// --------- Filters (from GET) ----------
$type     = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';
$period   = isset($_GET['period']) ? sanitize_text_field($_GET['period']) : '';
$material = isset($_GET['material']) ? sanitize_text_field($_GET['material']) : '';

$paged = max(1, get_query_var('paged'));
$meta_query = array('relation' => 'AND');

if ($type !== '') {
    $meta_query[] = array(
        'key'   => 'exhibit_type',
        'value' => $type,
        'compare' => '='
    );
}
if ($period !== '') {
    $meta_query[] = array(
        'key'   => 'period',
        'value' => $period,
        'compare' => 'LIKE'
    );
}
if ($material !== '') {
    $meta_query[] = array(
        'key'   => 'material',
        'value' => $material,
        'compare' => 'LIKE'
    );
}

// Only public exhibits (ACF true_false)
$meta_query[] = array(
    'key'   => 'is_public',
    'value' => 1,
    'compare' => '='
);

$query = new WP_Query(array(
    'post_type'      => 'exhibits',
    'posts_per_page' => 12,
    'paged'          => $paged,
    'meta_query'     => $meta_query,
    'orderby'        => 'date',
    'order'          => 'DESC',
));
?>

<main class="exhibits-archive-container">
    <section class="exhibits-archive-hero">
        <div class="container">
            <h1 class="archive-title" style="margin-top: 100px;">Εκθέματα</h1>
        </div>
    </section>

    <!-- Filters -->
    <section class="exhibits-filters">
        <form method="get" action="<?php echo esc_url( get_post_type_archive_link('exhibits') ); ?>">
            <?php
            // Πάρε τις επιλογές του ACF select για τον τύπο εκθέματος (αν υπάρχει)
            $type_field = function_exists('get_field_object') ? get_field_object('exhibit_type') : null;
            $choices = $type_field && !empty($type_field['choices']) ? $type_field['choices'] : array();
            ?>
            <div class="filters-grid">
                <div class="filter-item">
                    <label for="type">Τύπος</label>
                    <select id="type" name="type">
                        <option value="">Όλοι</option>
                        <?php foreach($choices as $k => $label): ?>
                            <option value="<?php echo esc_attr($k); ?>" <?php selected($type, $k); ?>>
                                <?php echo esc_html($label); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="filter-item">
                    <label for="period">Εποχή / Χρονολογία</label>
                    <input type="text" id="period" name="period" value="<?php echo esc_attr($period); ?>" placeholder="π.χ. 6ος αι. π.Χ., Ελληνιστική">
                </div>

                <div class="filter-item">
                    <label for="material">Υλικό</label>
                    <input type="text" id="material" name="material" value="<?php echo esc_attr($material); ?>" placeholder="π.χ. μάρμαρο, πηλός">
                </div>

                <div class="filter-actions">
                    <button type="submit" class="btn primary">Εφαρμογή</button>
                    <a class="btn ghost" href="<?php echo esc_url( get_post_type_archive_link('exhibits') ); ?>">Καθαρισμός</a>
                </div>
            </div>
        </form>
    </section>

    <!-- Grid -->
    <section class="exhibits-grid container">
        <?php if ( $query->have_posts() ) : ?>
            <div class="cards-grid">
            <?php while ( $query->have_posts() ) : $query->the_post();
                // εικόνα: featured -> πρώτο image από gallery -> placeholder
                $thumb_url = '';
                if ( has_post_thumbnail() ) {
                    $thumb_url = get_the_post_thumbnail_url(get_the_ID(), 'large');
                } else {
                    $gallery = function_exists('get_field') ? get_field('gallery') : array();
                    if (!empty($gallery) && isset($gallery[0]['sizes']['large'])) {
                        $thumb_url = $gallery[0]['sizes']['large'];
                    }
                }
                $period_v   = function_exists('get_field') ? get_field('period') : '';
                $type_v     = function_exists('get_field') ? get_field('exhibit_type') : '';
                $material_v = function_exists('get_field') ? get_field('material') : '';
                // Αν το ACF select επιστρέφει key, δείξε και label
                if ($type_field && isset($type_field['choices'][$type_v])) {
                    $type_v = $type_field['choices'][$type_v];
                }
            ?>
                <article class="exhibit-card show-on-scroll slide-up">
                    <a class="card-thumb" href="<?php the_permalink(); ?>">
                        <?php if ($thumb_url): ?>
                            <img src="<?php echo esc_url($thumb_url); ?>" alt="<?php the_title_attribute(); ?>">
                        <?php else: ?>
                            <div class="thumb-placeholder">Χωρίς εικόνα</div>
                        <?php endif; ?>
                    </a>
                    <div class="card-body">
                        <h2 class="card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <ul class="card-meta">
                            <?php if ($period_v):   ?><li><strong>Εποχή:</strong> <?php echo esc_html($period_v); ?></li><?php endif; ?>
                            <?php if ($type_v):     ?><li><strong>Τύπος:</strong>  <?php echo esc_html($type_v); ?></li><?php endif; ?>
                            <?php if ($material_v): ?><li><strong>Υλικό:</strong> <?php echo esc_html($material_v); ?></li><?php endif; ?>
                        </ul>
                        <a class="btn link" href="<?php the_permalink(); ?>">Περισσότερα</a>
                    </div>
                </article>
            <?php endwhile; ?>
            </div>

            <div class="pagination-wrap">
                <?php
                echo paginate_links( array(
                    'total'   => $query->max_num_pages,
                    'current' => $paged,
                    'prev_text' => '←',
                    'next_text' => '→',
                ) );
                ?>
            </div>

        <?php else: ?>
            <p class="no-results">Δεν βρέθηκαν εκθέματα με αυτά τα κριτήρια.</p>
        <?php endif; wp_reset_postdata(); ?>
    </section>
</main>

<?php get_footer(); ?>

<?php
/* Template Name: Contact-Template */
get_header();
?>

<main class="site-content">

    <section class="container">
        <div class="contact-wrapper-outside">

            <div class="contact-inner-wrapper">

                <div class="form__wrapper floating-labels-form main-form">

                    <?php
                        // Contact Form 7
                        echo do_shortcode('[contact-form-7 id="26af31d" title="Contact form"]');
                    ?>

                </div>

            </div>

        </div>
    </section>

    <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d50310.55899815668!2d23.697054243484978!3d37.990897629173496!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14a1bd1f067043f1%3A0x2736354576668ddd!2zzpHOuM6uzr3OsQ!5e0!3m2!1sel!2sgr!4v1740165743264!5m2!1sel!2sgr"
        width="100%"
        height="550"
        style="border:0;"
        allowfullscreen=""
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade"
        aria-label="<?php echo esc_attr__('Google Map', 'textdomain'); ?>"
    ></iframe>

</main>

<?php get_footer(); ?>

// Thumbnail Swiper (μικρές εικόνες)
var thumbSwiper = new Swiper(".thumb-swiper", {
    spaceBetween: 10,
    slidesPerView: 4, // 4 thumbnails αρχικά
    freeMode: true,
    watchSlidesProgress: true,
    breakpoints: {
        768: {
            slidesPerView: 5
        },
        1024: {
            slidesPerView: 6
        }
    }
});

// Hero (Main) Swiper (κύριες εικόνες)
var heroSwiper = new Swiper(".main-swiper", {
    effect: "fade",
    loop: true,
    spaceBetween: 10,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev"
    },
    thumbs: {
        swiper: thumbSwiper // Σύνδεση με το thumbnail Swiper
    }
});



//Home Stay Slider
// var names = [];
// jQuery(".stay-slider .swiper-slide").each(function(i) {
//   names.push(jQuery(this).data("name"));
// });

// var heroSlider = new Swiper(".stay-slider", {
//     effect: "fade",
//     loop: true,
//     autoHeight: true,
//     autoplay: {
//         delay: 8000,
//         disableOnInteraction: false,
//     },
//     pagination: {
//         el: '.swiper-pagination',
//         clickable: true,
//         renderBullet: function (index, className) {
//             return '<span class="text uppercase letter-spacing ' + className + '">' + (names[index]) + '<span class="diamond-spacer alt-color"></span></span>';
//         },
//     },
// });

//Area Guide Slider
// var names = [];
// jQuery(".area-guide-slider .swiper-slide").each(function(i) {
//   names.push(jQuery(this).data("name"));
// });

// var heroSlider = new Swiper(".area-guide-slider", {
//     effect: "fade",
//     loop: true,
//     autoHeight: true,
//     autoplay: {
//         delay: 8000,
//         disableOnInteraction: false,
//     },
//     pagination: {
//         el: '.swiper-pagination',
//         clickable: true,
//         renderBullet: function (index, className) {
//             return '<span class="text uppercase letter-spacing ' + className + '">' + (names[index]) + '<span class="diamond-spacer alt-color"></span></span>';
//         },
//     },
// });


//Single Stay Accommodation Gallery Slider
// let excursionSlider = new Swiper('.single-excursion-intro-wrapper', {
//     slidesPerView: 1,
//     loop: true,
//     centeredSlides: true,
//     spaceBetween: 20,
//     effect: 'fade',
//     navigation: {
//       nextEl: ".swiper-button-next.intro",
//       prevEl: ".swiper-button-prev.intro",
//     },
// });



//Slider with counter 
// let excursionsIntroSlider = new Swiper('.intro-excursions-slider-wrap', {
//     slidesPerView: 1.5,
//     loop: true,
//     spaceBetween: 20,
//     navigation: {
//       nextEl: ".swiper-button-next.intro-slider",
//       prevEl: ".swiper-button-prev.intro-slider",
//     },
//     on: {
//         init: updSwiperNumericPagination,
//         slideChange: updSwiperNumericPagination,
//     },
//     breakpoints: {
//         // when window width is >= 640px
//         700: {
//             slidesPerView: 2.5,
//         }
//     }
// });

// function updSwiperNumericPagination() {
//     jQuery(".swiper-counter").html('<span class="count">0' + (this.realIndex + 1) + '</span>');
// };

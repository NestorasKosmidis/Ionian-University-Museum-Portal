/**
 * QR → PDF (QR only, NO TEXT, NO LOGO)
 * Bulletproof version
 */

console.log('QR->PDF script LOADED (QR ONLY)');

async function toDataUrlFromImgSrc(src) {
  if (src.startsWith('data:image/')) return src;

  const res = await fetch(src, { cache: 'no-store' });
  if (!res.ok) throw new Error('QR image fetch failed');

  const blob = await res.blob();

  return await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('qr-pdf-btn');
  const container = document.getElementById('exhibit-qr');

  if (!btn || !container) {
    console.warn('QR->PDF: button or container not found');
    return;
  }

  if (btn.dataset.bound === '1') {
    console.warn('QR->PDF already bound, skipping');
    return;
  }
  btn.dataset.bound = '1';

  btn.addEventListener('click', async () => {
    try {
      console.log('QR->PDF click');

      const canvas = container.querySelector('canvas');
      const img = container.querySelector('img');

      let dataUrl = null;

      if (canvas && typeof canvas.toDataURL === 'function') {
        dataUrl = canvas.toDataURL('image/png');
      } else if (img && img.src) {
        dataUrl = await toDataUrlFromImgSrc(img.src);
      } else {
        alert('QR εικόνα δεν βρέθηκε');
        return;
      }

      if (!window.jspdf || !window.jspdf.jsPDF) {
        alert('jsPDF δεν φορτώθηκε');
        return;
      }

      const { jsPDF } = window.jspdf;
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const pageW = 210;

      // QR size & centering
      const qrSize = 90;
      const x = (pageW - qrSize) / 2;
      const y = 40;

      pdf.addImage(dataUrl, 'PNG', x, y, qrSize, qrSize);

      pdf.save('qr-only-' + Date.now() + '.pdf');

    } catch (e) {
      console.error('QR->PDF error:', e);
      alert('Σφάλμα δημιουργίας PDF (δες Console)');
    }
  });
});

<?php /* Template Name: About-Template */ ?>
<?php get_header(); ?>

<main class="site-content">
    <section class="about-hero">
        <div class="container">
            <div class="about-hero-content">
                <h1><?php the_field('about_title'); ?></h1>
                <p><?php the_field('about_description'); ?></p>
            </div>
            <div class="about-hero-image">
                <?php 
                $image = get_field('about_image');
                if ($image): ?>
                    <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>">
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="about-mission">
        <div class="container">
            <div class="mission-content">
                <h2><?php the_field('about_mission_title'); ?></h2>
                <p><?php the_field('about_mission_text'); ?></p>
            </div>
            <div class="mission-image">
                <?php 
                $mission_image = get_field('about_mission_image');
                if ($mission_image): ?>
                    <img src="<?php echo esc_url($mission_image['url']); ?>" alt="<?php echo esc_attr($mission_image['alt']); ?>">
                <?php endif; ?>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>

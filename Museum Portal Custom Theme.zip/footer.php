<?php get_template_part('custom-footer'); ?>

<?php wp_footer(); ?>

</body>
</html>

<?php get_header(); ?>

<?php
// Custom Fields από ACF
$alt_title = get_field('alt_title');
$description = get_field('description');
$period = get_field('period');
$exhibit_type = get_field('exhibit_type');
$material = get_field('material');
$dimensions = get_field('dimensions');
$museum_location = get_field('museum_location');
$origin = get_field('origin');
$gallery = get_field('gallery');
$video = get_field('video');
$model_3d = get_field('model_3d');
$audio_clip = get_field('audio_clip');
$sources = get_field('sources');
$is_public = get_field('is_public');
?>

<main class="single-exhibit-container">

    <!-- Τίτλος -->
    <section class="exhibit-intro show-on-scroll slide-up">
        <h1 class="exhibit-title"><?php the_title(); ?></h1>
        <?php if ($alt_title): ?>
            <h2 class="exhibit-alt-title">(<?php echo esc_html($alt_title); ?>)</h2>
        <?php endif; ?>
    </section>

    <!-- Gallery Εικόνων -->
    <?php if ($gallery): ?>
        <section class="exhibit-gallery show-on-scroll slide-up">
            <?php foreach ($gallery as $image): ?>
                <img src="<?php echo esc_url($image['sizes']['large']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" class="exhibit-image" />
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <!-- Βασικές Πληροφορίες -->
    <section class="exhibit-info show-on-scroll slide-up">
        <ul>
            <?php if ($period): ?>
                <li><strong>Χρονολογία/Εποχή:</strong> <?php echo esc_html($period); ?></li>
            <?php endif; ?>
            <?php if ($exhibit_type): ?>
                <li><strong>Τύπος Εκθέματος:</strong> <?php echo esc_html($exhibit_type); ?></li>
            <?php endif; ?>
            <?php if ($material): ?>
                <li><strong>Υλικό:</strong> <?php echo esc_html($material); ?></li>
            <?php endif; ?>
            <?php if ($dimensions): ?>
                <li><strong>Διαστάσεις:</strong> <?php echo esc_html($dimensions); ?></li>
            <?php endif; ?>
            <?php if ($museum_location): ?>
                <li><strong>Τοποθεσία στο Μουσείο:</strong> <?php echo esc_html($museum_location); ?></li>
            <?php endif; ?>
            <?php if ($origin): ?>
                <li><strong>Προέλευση / Χώρα:</strong> <?php echo esc_html($origin); ?></li>
            <?php endif; ?>
        </ul>
    </section>

    <!-- Περιγραφή -->
    <?php if ($description): ?>
        <section class="exhibit-description show-on-scroll slide-up" id="exhibit-3d">
            <h2>Περιγραφή</h2>
            <div><?php echo $description; ?></div>
        </section>
    <?php endif; ?>

    <!-- Video -->
    <?php if ($video): ?>
        <section class="exhibit-video show-on-scroll slide-up">
            <h2>Video Παρουσίαση</h2>
            <div class="video-embed">
                <iframe width="560" height="315" src="<?php echo esc_url($video); ?>" frameborder="0" allowfullscreen></iframe>
            </div>
        </section>
    <?php endif; ?>

    <!-- 3D Model -->
    <?php if ($model_3d): ?>
    <section class="exhibit-3d show-on-scroll slide-up" id="exhibit-3d">
        <h2>3D Μοντέλο</h2>

        <model-viewer
        id="exhibit-3d"
        src="<?php echo esc_url($model_3d); ?>"
        alt="3D Exhibit"
        auto-rotate
        camera-controls

        exposure="0.5"
        environment-image="neutral"
        tone-mapping="neutral"
        shadow-intensity="1"

        style="width:100%; height:400px; display:block;">
        </model-viewer>
    </section>

    <script type="module" src="https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
        const mv = document.getElementById('exhibit-3d');
        if (!mv) return;

        mv.addEventListener('load', () => {
            // Σταμάτα embedded animations που έρχονται από το GLB
            try { if (typeof mv.pause === 'function') mv.pause(); } catch(e){}
            try { mv.animationName = null; } catch(e){}
        });
        });
    </script>
    <?php endif; ?>


    <!-- Audio -->
    <?php if ($audio_clip): ?>
        <section class="exhibit-audio show-on-scroll slide-up">
            <h2>Ηχητικό Απόσπασμα</h2>
            <audio controls>
                <source src="<?php echo esc_url($audio_clip); ?>">
                Your browser does not support the audio element.
            </audio>
        </section>
    <?php endif; ?>

    <!-- Σχετικές Πηγές/Links -->
    <?php if ($sources): ?>
        <section class="exhibit-sources show-on-scroll slide-up">
            <h2>Σχετικές Πηγές</h2>
            <ul>
                <?php foreach ($sources as $item): ?>
                    <li>
                        <?php if ($item['source_url']): ?>
                            <a href="<?php echo esc_url($item['source_url']); ?>" target="_blank">
                                <?php echo esc_html($item['source_title']); ?>
                            </a>
                        <?php else: ?>
                            <?php echo esc_html($item['source_title']); ?>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    <?php endif; ?>

    <!-- QR Code (plugin shortcode ή template tag) -->

    <section class="exhibit-qr show-on-scroll slide-up"  id="exhibit-qr">
        <h2>QR Code</h2>
        <p>Σκανάρετε για να δείτε το έκθεμα στη συσκευή σας.</p>

        <?php echo do_shortcode('[kaya_qrcode dynamic_content="1"]'); ?>

        <button type="button" class="qr-pdf-btn" id="qr-pdf-btn">Λήψη ως PDF</button>
    </section>



    
    <!-- Ορατότητα -->
    <?php if (!$is_public): ?>
        <section class="exhibit-status show-on-scroll slide-up">
            <div class="alert alert-warning">Το έκθεμα αυτό δεν είναι ορατό στο κοινό.</div>
        </section>
    <?php endif; ?>

</main>

<?php get_footer(); ?>




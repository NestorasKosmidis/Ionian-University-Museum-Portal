<?php /* Custom Header */ ?>


<header class="custom-header<?php echo is_front_page() ? ' transparent' : ''; ?>">
    <?php if(function_exists( 'the_custom_logo' ) ):?>
        <?php if ( get_custom_logo() ) : ?>
            <?php the_custom_logo(); ?>
        <?php endif; ?>
    <?php endif;?>    
    
    

    <div class="header-center-wrap">
        <div class="header-menu-wrap">
            <?php wp_nav_menu( array( 'theme_location' => 'main-menu' ) ); ?>
        </div>
    </div>
    <?php $langHeader = false; ?>
    <?php if ( is_active_sidebar( 'wpml-custom-widget' ) ) : ?>
        <?php $langHeader = true; ?>
    <?php endif; ?>
    <div class="header-right-wrap <?php echo $langHeader == true ? ' lang-header' : '' ; ?>">
        <?php if ( get_field('contact_link','options') ) : ?>
            <a href="<?php the_field('contact_link','options'); ?>" class="border-btn-wrap">
                <?php _e('Contact us','text-domain'); ?>
            </a>
        <?php endif; ?>
        <?php if ( get_field('book_link','options') ) : ?>
            <a href="<?php the_field('book_link','options'); ?>" class="border-btn-wrap">
                <?php _e('Book Now','text-domain'); ?>
            </a>
        <?php endif; ?>

        <?php if ( is_active_sidebar( 'wpml-custom-widget' ) ) : ?>
            <div class="header-lang-switcher">
                <?php dynamic_sidebar( 'wpml-custom-widget' ); ?>
            </div>
        <?php endif; ?>

    </div>

</header>



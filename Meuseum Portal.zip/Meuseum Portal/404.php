<?php /* 404 */ ?>

<?php get_header(); ?>

<main class="site-content">

        <section class="error-page-wrapper">
            <?php
            $image = get_field('error_image','options');
            $size = 'full';
            ?>
            <?php echo wp_get_attachment_image( $image['id'], $size ); ?>
            <div class="error-page-content-wrap">
                <?php if (get_field('error_title','options')): ?>
                    <h1 class="hero-title error">
                        <?php the_field('error_title','options'); ?>
                    </h1>
                <?php endif; ?>
                <?php if (get_field('error_subtitle','options')): ?>
                    <span class="main-section-subtitle error">
                        <?php the_field('error_subtitle','options'); ?>
                    </span>
                <?php endif; ?>
                <?php if (get_field('error_text','options')): ?>
                    <span class="main-section-text error">
                        <?php the_field('error_text','options'); ?>
                    </span>
                <?php endif; ?>
                <?php if (get_field('error_button_link','options') && get_field('error_button_text','options')): ?>
                    <div class="button-wrapper">
                        <a class="button-wrap blue-btn" href="<?php the_field('error_button_link','options') ?>">
                            <span><?php the_field('error_button_text','options'); ?></span>
                        </a>
                    </div>
                <?php endif; ?>

            </div>
        </section>

</main>

<?php get_footer(); ?>

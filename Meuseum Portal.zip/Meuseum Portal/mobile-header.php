<?php /* Mobile Header */ ?>

<div class="mob-header">
    <div class="header-wrap-mobile">
        <div class="header-logo-wrap mob">
            <a class="headerLogo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                <?php
                    $image = get_field('mobile_logo','options');
                    if( !empty($image) ): ?>
                        <img src="<?php echo $image['sizes']['medium']; ?>" alt="<?php echo $image['alt']; ?>"/>
                <?php endif; ?>
            </a>
        </div>
        <div class="burger-menu-wrap-mob">
            <div class="burger-menu">
                <div></div>
            </div>
        </div>
    </div>
    <div class="menu-mob">
        <div class="menu-mob-wrap">
            <?php wp_nav_menu( array( 'theme_location' => 'main-menu' ) ); ?>

            <?php if ( is_active_sidebar( 'wpml-custom-widget-mobile' ) ) : ?>
                <div class="header-lang-switcher mob">
                    <?php dynamic_sidebar( 'wpml-custom-widget-mobile' ); ?>
                </div>
            <?php endif; ?>

            <div class="mob-menu-bottom">
                <div class="mob-socials-wrap">
                    <div class="mob-socials-wrap-bot">

                        <?php if (get_field('facebook','options')): ?>
                            <a href="<?php the_field('facebook','options') ?>" class="social-btn" target="_blank">
                                <span class="icon-facebook"></span>
                            </a>
                        <?php endif; ?>

                        <?php if (get_field('instagram','options')): ?>
                            <a href="<?php the_field('instagram','options') ?>" class="social-btn" target="_blank">
                                <span class="icon-instagram"></span>
                            </a>
                        <?php endif; ?>

                        <?php if (get_field('twitter','options')): ?>
                            <a href="<?php the_field('twitter','options') ?>" class="social-btn" target="_blank">
                                <span class="icon-x-twitter"></span>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

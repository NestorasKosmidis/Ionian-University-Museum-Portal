<?php /* Template Name: Homepage-Template */ ?>

<?php get_header(); ?>

<main class="site-content">

    <section class="intro-wrapper">
        <div class="intro-wrap">
            <div class="hero-slider-wrapper">
                <div class="single-slider-wrapper swiper-container main-swiper">
                    <div class="swiper-overlay"></div>

                    <div class="swiper-wrapper">
                        <?php 
                        $images = get_field('intro_slider');
                        $size = 'full'; 
                        if ($images): ?>
                            <?php foreach ($images as $image): ?>
                                <div class="swiper-slide">
                                    <?php echo wp_get_attachment_image($image['id'], $size); ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>


                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>

                <!-- Thumbnail Swiper -->
                <div class="thumb-slider-wrapper swiper-container thumb-swiper">
                    <div class="swiper-wrapper">
                        <?php 
                        if ($images): ?>
                            <?php foreach ($images as $image): ?>
                                <div class="swiper-slide">
                                    <?php echo wp_get_attachment_image($image['id'], 'thumbnail'); ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>


            <div class="intro-content-wrapper mid-container show-on-scroll slide-up">
                <span class=" pretitle">
                    <?php the_field('intro_pretitle'); ?>
                </span>
                <h1 class="intro-title">
                    <?php the_field('intro_title'); ?>
                </h1>
                <?php if (get_field('intro_button_link')): ?>
                    <div class="border-btn-wrapper">
                        <a class="border-btn-wrap white button" href="<?php the_field('intro_button_link') ?>">
                            <?php if (get_field('intro_button_text')): ?>
                                <?php the_field('intro_button_text') ?>
                            <?php else: ?>
                                <?php _e('Learn More','text-domain'); ?>
                            <?php endif; ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>


    <section class="welcome-row container show-on-scroll slide-up">
        <div class="container">
            <div class="welcome-content">
                <h2 class="welcome-title"><?php the_field('welcome_row_title'); ?></h2>
                <div class="welcome-row-text"><?php the_field('welcome_row_text'); ?></div>
                <?php if (get_field('welcome_row_button_text')) : ?>
                    <a href="/exhibits" class="btn-scroll button">
                        <?php the_field('welcome_row_button_text'); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </section>



    <?php if( have_rows('repeater') ): ?>
        <section class="repeater-wrap repeater-grid container " id="content">
            <?php $count = 1; ?>
            <?php while( have_rows('repeater') ): the_row();
                $image = get_sub_field('image');
                ?>
                <div class="main-box-repeat-wrap show-on-scroll slide-up <?php echo $count % 2 == 0 ? ' reverse' : ''; ?>">
                    <div class="main-box-repeat-content grey-bg">
                        <h3 class="main-style-title">
                            <?php the_sub_field('title'); ?>
                        </h3>
                        <div class="main-style-text">
                            <?php the_sub_field('text'); ?>
                        </div>
                    </div>
                    <div class="main-box-repeat-image">
                        <?php echo wp_get_attachment_image( $image['id'], 'large' ); ?>
                    </div>
                </div>
                <?php $count = $count + 1; ?>
            <?php endwhile; ?>
        </section>
    <?php endif; ?>



    

</main>

<?php get_footer(); ?>






<script>
// document.addEventListener("DOMContentLoaded", function() {
//     document.querySelector(".btn-scroll").addEventListener("click", function(e) {
//         e.preventDefault();
//         document.querySelector("#activities").scrollIntoView({
//             behavior: "smooth"
//         });
//     });
// });

$(document).on('click', 'a.btn-scroll', function (e) {
  const href = $(this).attr('href');

  // Αν είναι κανονικό URL (π.χ. https://...), άφησέ το να δουλέψει φυσιολογικά
  if (!href || !href.startsWith('#')) return;

  // ΜΟΝΟ για anchors κάνουμε smooth scroll
  e.preventDefault();

  const $target = $(href);
  if ($target.length) {
    $('html, body').animate({ scrollTop: $target.offset().top }, 600);
  }
});

</script>


















































